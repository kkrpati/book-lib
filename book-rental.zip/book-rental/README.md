# Library Book Rental REST API


## Description:
REST API for book rental service from a library. It uses standard HTTP methods like GET, PUT, POST and DELETE. Spring Boot 2, Lombok and H2 in-memory DB are used.
Manual testing during th development is done using POSTMAN tool.

**Entities and their relationships are considered as following:**
- Book
  - ID, Title, Author, Publisher and Publishing Year
- Member
  - ID, First Name and Last Name
- Book. Book Item is an individual item (Stock unit) of the actual book.
  - ID, Available, Book and Barcode.
    * Barcode is to represent each individual piece of the book (This may not the true in real world library). I should have used some other field name to identify the individual book apart from the ID. Or it may not be needed at all.
    * For every book entity, there are N number of BookItem entities. Book and BookItem have one to many relationship.
- Rental
  - ID, BookITem, Member, RentedFrom, IsDamaged, IsLateReturn, RentalDurationInDays and ReturnedOn
  * ReturnedOn field value will contain the value when the book is returned. If it has null value, the book is not returned yet.
  * Each Rental will have one BookItem and one Member. One Member may have multiple Rentals.
  * IsLateReturn is calculated using the RentalDurationInDays, ReturnedOn and RentedFrom.
 
**Librarian will be able to do the followings actions:**
- Creating a book
- Creating a member
- Creating a book item which needs an already created book
- Creating a rental which needs a book item and a member already created and the book is in available status. This action changes the available status to false
- Returning the book - As part of this, returned date, damage status, late return and available status are updated.

** Returning the book is achieved using PUT method.
** Each entity has corresponding Spring Rest Controllers which has additional CRUD operations other the actions mentioned above.
** For brevity, I used Book and Member JPA entities as part of HTTP Request and Response in the Controllers. BookItem and Rental are of complex type
and it would be difficult for use to send the whole JSON request as part of HTTP call. Hence I created corresponding DTOs which will take only Book ID and Member ID
as part of the request instead of Book or Member entities.


## Example JSON messages:
- Create Book
{
    "title": "title2",
    "author": "author2",
    "publisher": "publisher2",
    "publishingYear": 2
}
- Create Book Item
{
    "bookId": 1,
    "barcode": "barCode2"
}
- Create Member
{
    "firstName": "firstName1",
    "lastName": "lastName1"
}
- Create Rental
{
    "bookItemId": 2,
    "memberId": 3,
    "rentalDurationInDays" : 7,
    "rentedFrom" : "2021-05-13"
}
- Return Rental (http://localhost:8080/library/v1/rentals/5)

{
    "isDamaged" : true,
    "returnedOn" : "2021-05-20"
}

## Testing
    -Integration testing is added in each controller. RentalControllerIntegrationTest handles the final functionality of librarian.