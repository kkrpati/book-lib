package com.library.bookrental.controller;


import com.library.bookrental.BookRentalApplication;
import com.library.bookrental.dto.BookItemDto;
import com.library.bookrental.entity.Book;
import com.library.bookrental.entity.BookItem;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.*;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit.jupiter.SpringExtension;


import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;


@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = BookRentalApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class BookItemControllerTest {
	@Autowired
	private TestRestTemplate restTemplate;

	@LocalServerPort
	private int port;

	private String getRootUrl() {
		return "http://localhost:" + port;
	}

	@Test
	public void testCreateBookItem() {
		Book book = new Book("title1", "author", "publisher", 2010);
		ResponseEntity<Book> postResponse = restTemplate.postForEntity(getRootUrl() + "/library/v1/books", book, Book.class);

		BookItemDto bookItemDto = new BookItemDto(null, postResponse.getBody().getId(), "barcode", true);
		ResponseEntity<BookItem> postResponseBookItem = restTemplate.postForEntity(getRootUrl() + "/library/v1/book/items", bookItemDto, BookItem.class);

		assertEquals(postResponseBookItem.getBody().getBarcode(), bookItemDto.getBarcode());
		assertEquals(postResponseBookItem.getBody().getBook().getAuthor(), book.getAuthor());
		assertEquals(postResponseBookItem.getBody().getBook().getTitle(), book.getTitle());
		assertEquals(postResponseBookItem.getBody().getBook().getPublisher(), book.getPublisher());
		assertEquals(postResponseBookItem.getBody().getBook().getPublishingYear(), book.getPublishingYear());
	}

	@Test
	public void testGetAllBookItems() {
		Book book1 = new Book("title1", "author", "publisher", 2010);
		Book book2 = new Book("title2", "author2", "publisher", 20110);
		ResponseEntity<Book> postResponse1 = restTemplate.postForEntity(getRootUrl() + "/library/v1/books", book1, Book.class);
		ResponseEntity<Book> postResponse2 = restTemplate.postForEntity(getRootUrl() + "/library/v1/books", book2, Book.class);
		BookItemDto bookItemDto1 = new BookItemDto(null, postResponse1.getBody().getId(), "barcode1", true);
		BookItemDto bookItemDto2 = new BookItemDto(null, postResponse1.getBody().getId(), "barcode2", true);
		BookItemDto bookItemDto3 = new BookItemDto(null, postResponse2.getBody().getId(), "barcode3", true);
		BookItemDto bookItemDto4 = new BookItemDto(null, postResponse2.getBody().getId(), "barcode4", true);
		restTemplate.postForEntity(getRootUrl() + "/library/v1/book/items", bookItemDto1, BookItem.class);
		restTemplate.postForEntity(getRootUrl() + "/library/v1/book/items", bookItemDto2, BookItem.class);
		restTemplate.postForEntity(getRootUrl() + "/library/v1/book/items", bookItemDto3, BookItem.class);
		restTemplate.postForEntity(getRootUrl() + "/library/v1/book/items", bookItemDto4, BookItem.class);
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> entity = new HttpEntity<String>(null, headers);

		ResponseEntity<List> response = restTemplate.exchange(getRootUrl() + "/library/v1/book/items",
				HttpMethod.GET, entity, List.class);

		assertEquals(4, response.getBody().size());

	}

	@Test
	public void testGetBookItemById() {
		Book book1 = new Book("title1", "author", "publisher", 2010);
		Book book2 = new Book("title2", "author2", "publisher", 20110);
		ResponseEntity<Book> postResponse1 = restTemplate.postForEntity(getRootUrl() + "/library/v1/books", book1, Book.class);
		ResponseEntity<Book> postResponse2 = restTemplate.postForEntity(getRootUrl() + "/library/v1/books", book2, Book.class);

		BookItemDto bookItemDto1 = new BookItemDto(null, postResponse1.getBody().getId(), "barcode1", true);
		BookItemDto bookItemDto2 = new BookItemDto(null, postResponse2.getBody().getId(), "barcode2", true);
		ResponseEntity<BookItem> bookItem1 = restTemplate.postForEntity(getRootUrl() + "/library/v1/book/items", bookItemDto1, BookItem.class);
		ResponseEntity<BookItem> bookItem2 = restTemplate.postForEntity(getRootUrl() + "/library/v1/book/items", bookItemDto2, BookItem.class);

		Long bookItemId = bookItem1.getBody().getId();
		BookItem returnedBookById1 = restTemplate.getForObject(getRootUrl() + "/library/v1/book/items/"+bookItemId, BookItem.class);

		assertEquals(returnedBookById1.getId(), bookItemId);
		assertEquals(returnedBookById1.getBook().getAuthor(), book1.getAuthor());
		assertEquals(returnedBookById1.getBook().getTitle(), book1.getTitle());
		assertEquals(returnedBookById1.getBook().getPublisher(), book1.getPublisher());
		assertEquals(returnedBookById1.getBook().getPublishingYear(), book1.getPublishingYear());
	}

	@Test
	public void testUpdateBookItem() {
		Book book1 = new Book("title1", "author", "publisher", 2010);
		Book book2 = new Book("title2", "author2", "publisher", 20110);
		ResponseEntity<Book> postResponse1 = restTemplate.postForEntity(getRootUrl() + "/library/v1/books", book1, Book.class); //Create a new book
		ResponseEntity<Book> postResponse2 = restTemplate.postForEntity(getRootUrl() + "/library/v1/books", book2, Book.class);

		BookItemDto bookItemDto1 = new BookItemDto(null, postResponse1.getBody().getId(), "barcode1", true); //Create a new book item
		ResponseEntity<BookItem> returnedBookItem = restTemplate.postForEntity(getRootUrl() + "/library/v1/book/items", bookItemDto1, BookItem.class);

		BookItemDto bookItemDtoWithNewBook = new BookItemDto(null, postResponse2.getBody().getId(), "barcode2", true); //Updating with second book.
		restTemplate.put(getRootUrl() + "/library/v1/book/items/"+returnedBookItem.getBody().getId(), bookItemDtoWithNewBook, BookItemDto.class);

		BookItem updatedBookItem = restTemplate.getForObject(getRootUrl() + "/library/v1/book/items/"+returnedBookItem.getBody().getId(), BookItem.class);
		assertEquals(updatedBookItem.getBarcode(), bookItemDtoWithNewBook.getBarcode());
		assertEquals(updatedBookItem.getBook().getPublisher(), book2.getPublisher());
		assertEquals(updatedBookItem.getBook().getAuthor(), book2.getAuthor());
		assertEquals(updatedBookItem.getBook().getTitle(), book2.getTitle());
	}

/*
	@Test
	public void testDeleteBookItem() {
		Book book1 = new Book("title1", "author", "publisher", 2010);
		ResponseEntity<Book> postResponse1 = restTemplate.postForEntity(getRootUrl() + "/library/v1/books", book1, Book.class);

		BookItemDto bookItemDto1 = new BookItemDto(null, postResponse1.getBody().getId(), "barcode1", true);
		BookItemDto bookItemDto2 = new BookItemDto(null, postResponse1.getBody().getId(), "barcode2", true);
		ResponseEntity<BookItem> returnedBookItem1 = restTemplate.postForEntity(getRootUrl() + "/library/v1/book/items", bookItemDto1, BookItem.class);
		ResponseEntity<BookItem> returnedBookItem2 = restTemplate.postForEntity(getRootUrl() + "/library/v1/book/items", bookItemDto2, BookItem.class);

		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> entity = new HttpEntity<String>(null, headers);
		ResponseEntity<List> response = restTemplate.exchange(getRootUrl() + "/library/v1/book/items/",
				HttpMethod.GET, entity, List.class);
		assertEquals(2, response.getBody().size());

		restTemplate.delete(getRootUrl() + "/library/v1/book/items/"+returnedBookItem2.getBody().getId());
		response = restTemplate.exchange(getRootUrl() + "/library/v1/book/items/",
				HttpMethod.GET, entity, List.class);
		assertEquals(1, response.getBody().size());
	}
*/

}
