package com.library.bookrental.controller;

import com.library.bookrental.BookRentalApplication;
import com.library.bookrental.entity.Member;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;


@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = BookRentalApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class MemeberControllerTest {
	@Autowired
	private TestRestTemplate restTemplate;

	@LocalServerPort
	private int port;

	private String getRootUrl() {
		return "http://localhost:" + port;
	}

	@Test
	public void testCreateMember() {
		Member member = new Member("firstName", "lastName");
		ResponseEntity<Member> postResponse = restTemplate.postForEntity(getRootUrl() + "/library/v1/members", member, Member.class);
		Member returnedMember = postResponse.getBody();

		assertEquals(returnedMember.getFirstName(), member.getFirstName());
		assertEquals(returnedMember.getLastName(), member.getLastName());

	}

	@Test
	public void testGetAllMembers() {
		Member member1 = new Member("firstName1", "lastName1");
		Member member2 = new Member("firstName2", "lastName2");
		ResponseEntity<Member> postResponse1 = restTemplate.postForEntity(getRootUrl() + "/library/v1/members", member1, Member.class);
		ResponseEntity<Member> postResponse2 = restTemplate.postForEntity(getRootUrl() + "/library/v1/members", member2, Member.class);
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> entity = new HttpEntity<String>(null, headers);

		ResponseEntity<List> response = restTemplate.exchange(getRootUrl() + "/library/v1/members",
				HttpMethod.GET, entity, List.class);

		assertEquals(2, response.getBody().size());

	}

	@Test
	public void testGetMemberById() {
		Member member1 = new Member("firstName1", "lastName1");
		Member member2 = new Member("firstName2", "lastName2");
		restTemplate.postForEntity(getRootUrl() + "/library/v1/members", member1, Member.class);
		restTemplate.postForEntity(getRootUrl() + "/library/v1/members", member2, Member.class);

		Member returnedMemberById1 = restTemplate.getForObject(getRootUrl() + "/library/v1/members/1", Member.class);

		assertEquals(returnedMemberById1.getId(), 1);
		assertEquals(returnedMemberById1.getFirstName(), member1.getFirstName());
		assertEquals(returnedMemberById1.getLastName(), member1.getLastName());

	}

	@Test
	public void testUpdateMember() {
		Member member = new Member("firstName", "lastName");
		restTemplate.postForEntity(getRootUrl() + "/library/v1/members", member, Member.class);
		member.setFirstName("updatedFirstName");
		member.setLastName("updatedLastName");
		restTemplate.put(getRootUrl() + "/library/v1/members/1", member, Member.class);
		Member updatedMember = restTemplate.getForObject(getRootUrl() + "/library/v1/members/1", Member.class);
		assertEquals(updatedMember.getFirstName(), "updatedFirstName");
		assertEquals(updatedMember.getLastName(), "updatedLastName");

	}

	@Test
	public void testDeleteMember() {
		Member member1 = new Member("firstName1", "lastName1");
		Member member2 = new Member("firstName2", "lastName2");
		Member member3 = new Member("firstName3", "lastName3");
		restTemplate.postForEntity(getRootUrl() + "/library/v1/members", member1, Member.class);
		restTemplate.postForEntity(getRootUrl() + "/library/v1/members", member2, Member.class);
		restTemplate.postForEntity(getRootUrl() + "/library/v1/members", member3, Member.class);

		restTemplate.delete(getRootUrl() + "/library/v1/members/1");
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> entity = new HttpEntity<String>(null, headers);

		ResponseEntity<List> response = restTemplate.exchange(getRootUrl() + "/library/v1/members",
				HttpMethod.GET, entity, List.class);
		assertEquals(2, response.getBody().size());
	}
}
