package com.library.bookrental.controller;


import com.library.bookrental.BookRentalApplication;
import com.library.bookrental.dto.BookItemDto;
import com.library.bookrental.dto.RentalDto;
import com.library.bookrental.entity.Book;
import com.library.bookrental.entity.BookItem;
import com.library.bookrental.entity.Member;
import com.library.bookrental.entity.Rental;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.*;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;


@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = BookRentalApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class RentalControllerTest {
	@Autowired
	private TestRestTemplate restTemplate;

	@LocalServerPort
	private int port;

	private String getRootUrl() {
		return "http://localhost:" + port;
	}

	@Test
	public void contextLoads() {

	}

	@Test
	public void testCreateRental() {
		Member member = createMember("FirstName", "LastName");
		BookItem bookItem = createBookItem("title", "author", "publisher", 2010);
		LocalDate rentedOn = LocalDate.now();
		int rentalDurationInDays=7;
        Rental rental = createRental(member, bookItem, rentedOn, rentalDurationInDays);

		assertEquals(rental.getRentalDurationInDays(), rentalDurationInDays);
		assertEquals(rental.getRentedFrom(),rentedOn);
		assertEquals(rental.getBookItem().getId(), bookItem.getId());
		assertEquals(rental.getMember().getId(),member.getId());
		assertEquals(rental.getReturnedOn(),null);
		assertEquals(rental.getBookItem().isAvailable(),false);
	}

	@Test
	public void testAlreadyRentedItem() {
		Member member = createMember("FirstName", "LastName");
		BookItem bookItem = createBookItem("title", "author", "publisher", 2010);
		LocalDate rentedOn = LocalDate.now();
		int rentalDurationInDays=7;
		Rental rental = createRental(member, bookItem, rentedOn, rentalDurationInDays);
		assertEquals(rental.getBookItem().isAvailable(),false);

		RentalDto rentalDto = new RentalDto(null, bookItem.getId(), member.getId(), rentedOn, null, rentalDurationInDays, false);
		ResponseEntity<Rental> postResponse = restTemplate.postForEntity(getRootUrl() + "/library/v1/rentals", rentalDto, Rental.class);

		assertEquals(postResponse.getStatusCode(), HttpStatus.NOT_FOUND);

	}

	@Test
	public void testRentalReturn(){
		Member member = createMember("FirstName", "LastName");
		BookItem bookItem = createBookItem("title", "author", "publisher", 2010);
		LocalDate rentedOn = LocalDate.now().minusDays(7);
		Integer rentalDurationInDays=7;
		Rental rental = createRental(member, bookItem, rentedOn, rentalDurationInDays);

		LocalDate returnedOn = LocalDate.now();
		updateRental(null, null, null, null, returnedOn, rental.getId(), false);

		Rental closedRental = restTemplate.getForObject(getRootUrl() + "/library/v1/rentals/"+rental.getId(), Rental.class);

		assertEquals(closedRental.getReturnedOn(), returnedOn);
		assertEquals(closedRental.isDamaged(), false);
		assertEquals(closedRental.isLateReturn(), false);
		assertEquals(closedRental.getBookItem().isAvailable(),true);

	}

	@Test
	public void testLateRentalReturn(){
		Member member = createMember("FirstName", "LastName");
		BookItem bookItem = createBookItem("title", "author", "publisher", 2010);
		LocalDate rentedOn = LocalDate.now().minusDays(8);
		Integer rentalDurationInDays=7;
		Rental rental = createRental(member, bookItem, rentedOn, rentalDurationInDays);

		LocalDate returnedOn = LocalDate.now();
		updateRental(null, null, null, null, returnedOn, rental.getId(), false);

		Rental closedRental = restTemplate.getForObject(getRootUrl() + "/library/v1/rentals/"+rental.getId(), Rental.class);

		assertEquals(closedRental.getReturnedOn(), returnedOn);
		assertEquals(closedRental.isLateReturn(), true);
		assertEquals(closedRental.isDamaged(), false);
		assertEquals(closedRental.getBookItem().isAvailable(),true);
	}


	@Test
	public void testDamagedRentalReturn(){
		Member member = createMember("FirstName", "LastName");
		BookItem bookItem = createBookItem("title", "author", "publisher", 2010);
		LocalDate rentedOn = LocalDate.now().minusDays(8);
		Integer rentalDurationInDays=7;
		Rental rental = createRental(member, bookItem, rentedOn, rentalDurationInDays);

		LocalDate returnedOn = LocalDate.now();
		updateRental(null, null, null, null, returnedOn, rental.getId(), true);

		Rental closedRental = restTemplate.getForObject(getRootUrl() + "/library/v1/rentals/"+rental.getId(), Rental.class);

		assertEquals(closedRental.getReturnedOn(), returnedOn);
		assertEquals(closedRental.isLateReturn(), true);
		assertEquals(closedRental.isDamaged(), true);
		assertEquals(closedRental.getBookItem().isAvailable(),true);
	}


	@Test
	public void testGetAllRentals() {

		Member member = createMember("FirstName", "LastName");
		BookItem bookItem = createBookItem("title", "author", "publisher", 2010);
		LocalDate rentedOn = LocalDate.now();
        int rentalDurationInDays=7;
        createRental(member, bookItem, rentedOn, rentalDurationInDays);

		Member member1 = createMember("FirstName1", "LastName1");
		BookItem bookItem1 = createBookItem("title1", "author1", "publisher1", 2010);
        LocalDate rentedOn1 = LocalDate.now();
        int rentalDurationInDays1 = 4;
        createRental(member1, bookItem1, rentedOn1, rentalDurationInDays1);

		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> entity = new HttpEntity<String>(null, headers);

		ResponseEntity<List> response = restTemplate.exchange(getRootUrl() + "/library/v1/rentals",
				HttpMethod.GET, entity, List.class);

		assertEquals(2, response.getBody().size());

	}

	@Test
	public void testGetRentalById() {

		Member member = createMember("FirstName", "LastName");
		BookItem bookItem = createBookItem("title", "author", "publisher", 2010);
        LocalDate rentedOn = LocalDate.now();
        int rentalDurationInDays=7;
        Rental rental1 = createRental(member, bookItem, rentedOn, rentalDurationInDays);

		Member member1 = createMember("FirstName1", "LastName1");
		BookItem bookItem1 = createBookItem("title1", "author1", "publisher1", 2010);
        LocalDate rentedOn1 = LocalDate.now();
        int rentalDurationInDays1=4;
        createRental(member1, bookItem1, rentedOn1, rentalDurationInDays1);;

		assertEquals(rental1.getRentalDurationInDays(), rentalDurationInDays);
		assertEquals(rental1.getRentedFrom(),rentedOn);
		assertEquals(rental1.getBookItem().getId(), bookItem.getId());
		assertEquals(rental1.getMember().getId(),member.getId());
		assertEquals(rental1.getReturnedOn(),null);
	}

	@Test
	public void testUpdateRental() {
		Member member = createMember("FirstName", "LastName");
		BookItem bookItem = createBookItem("title", "author", "publisher", 2010);
		LocalDate rentedOn = LocalDate.now().minusDays(1);
		int rentalDurationInDays=7;
		Rental returnedRental = createRental(member, bookItem, rentedOn, rentalDurationInDays);

		int updatedRentalDurationInDays=5;
		RentalDto updatedRentalDto = new RentalDto(null, bookItem.getId(), member.getId(), rentedOn, null, updatedRentalDurationInDays, false);
		restTemplate.put(getRootUrl() + "/library/v1/rentals/"+returnedRental.getId(), updatedRentalDto, RentalDto.class);

		Rental updatedRental = restTemplate.getForObject(getRootUrl() + "/library/v1/rentals/"+returnedRental.getId(), Rental.class);

		assertEquals(updatedRental.getRentalDurationInDays(), updatedRentalDto.getRentalDurationInDays());
		assertEquals(updatedRental.getRentedFrom(),rentedOn);
		assertEquals(updatedRental.getBookItem().getId(), bookItem.getId());
		assertEquals(updatedRental.getMember().getId(),member.getId());
		assertEquals(updatedRental.getReturnedOn(),null);
	}

	public void updateRental(Long memberId, Long bookItemId, LocalDate rentedOn, Integer rentalDurationInDays, LocalDate returnedOn, long rentalId, boolean damaged){
		RentalDto updatedRentalDto = new RentalDto(null, bookItemId, memberId, rentedOn, returnedOn, rentalDurationInDays, damaged);
		restTemplate.put(getRootUrl() + "/library/v1/rentals/"+rentalId, updatedRentalDto, RentalDto.class);
	}

	public Rental createRental(Member member, BookItem bookItem, LocalDate rentedOn, int rentalDurationInDays){
        RentalDto rentalDto = new RentalDto(null, bookItem.getId(), member.getId(), rentedOn, null, rentalDurationInDays, false);
        ResponseEntity<Rental> postResponse = restTemplate.postForEntity(getRootUrl() + "/library/v1/rentals", rentalDto, Rental.class);
        return postResponse.getBody();
    }

    public BookItem createBookItem(String title, String author, String publisher, int publishingYear){
        Book book = new Book(title, author, publisher, publishingYear);
        ResponseEntity<Book> postResponse = restTemplate.postForEntity(getRootUrl() + "/library/v1/books", book, Book.class);

        BookItemDto bookItemDto = new BookItemDto(null, postResponse.getBody().getId(), "barcode", true);
        ResponseEntity<BookItem> postResponseBookItem = restTemplate.postForEntity(getRootUrl() + "/library/v1/book/items", bookItemDto, BookItem.class);
        return postResponseBookItem.getBody();
    }

    public Member createMember(String firstName, String lastName){
        return restTemplate.postForEntity(getRootUrl() + "/library/v1/members", new Member(firstName, lastName), Member.class).getBody();
        }
}
