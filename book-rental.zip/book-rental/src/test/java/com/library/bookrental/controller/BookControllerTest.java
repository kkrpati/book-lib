package com.library.bookrental.controller;


import com.library.bookrental.BookRentalApplication;
import com.library.bookrental.entity.Book;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.*;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit.jupiter.SpringExtension;


import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;


@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = BookRentalApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class BookControllerTest {
	@Autowired
	private TestRestTemplate restTemplate;

	@LocalServerPort
	private int port;

	private String getRootUrl() {
		return "http://localhost:" + port;
	}

	@Test
	public void contextLoads() {

	}


	@Test
	public void testCreateBook() {
		Book book = new Book("title1", "author", "publisher", 2010);
		ResponseEntity<Book> postResponse = restTemplate.postForEntity(getRootUrl() + "/library/v1/books", book, Book.class);
		Book returnedBook = postResponse.getBody();

		assertEquals(returnedBook.getAuthor(), book.getAuthor());
		assertEquals(returnedBook.getTitle(), book.getTitle());
		assertEquals(returnedBook.getPublisher(), book.getPublisher());
		assertEquals(returnedBook.getPublishingYear(), book.getPublishingYear());
	}

	@Test
	public void testGetAllBooks() {
		Book book1 = new Book("title1", "author", "publisher", 2010);
		Book book2 = new Book("title2", "author2", "publisher", 20110);
		ResponseEntity<Book> postResponse1 = restTemplate.postForEntity(getRootUrl() + "/library/v1/books", book1, Book.class);
		ResponseEntity<Book> postResponse2 = restTemplate.postForEntity(getRootUrl() + "/library/v1/books", book2, Book.class);
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> entity = new HttpEntity<String>(null, headers);

		ResponseEntity<List> response = restTemplate.exchange(getRootUrl() + "/library/v1/books",
				HttpMethod.GET, entity, List.class);

		assertEquals(2, response.getBody().size());

	}

	@Test
	public void testGetBookById() {
		Book book1 = new Book("title1", "author", "publisher", 2010);
		Book book2 = new Book("title2", "author2", "publisher", 20110);
		restTemplate.postForEntity(getRootUrl() + "/library/v1/books", book1, Book.class);
		restTemplate.postForEntity(getRootUrl() + "/library/v1/books", book2, Book.class);

		Book returnedBookById1 = restTemplate.getForObject(getRootUrl() + "/library/v1/books/1", Book.class);

		assertEquals(returnedBookById1.getId(), 1);
		assertEquals(returnedBookById1.getAuthor(), book1.getAuthor());
		assertEquals(returnedBookById1.getTitle(), book1.getTitle());
		assertEquals(returnedBookById1.getPublisher(), book1.getPublisher());
		assertEquals(returnedBookById1.getPublishingYear(), book1.getPublishingYear());
	}

	@Test
	public void testUpdateBook() {
		Book book = new Book("title1", "author", "publisher", 2010);
		restTemplate.postForEntity(getRootUrl() + "/library/v1/books", book, Book.class);
		book.setTitle("updatedTitle1");
		book.setAuthor("updatedAuthor");
		book.setPublisher("updatedPublisher");
		restTemplate.put(getRootUrl() + "/library/v1/books/1", book, Book.class);
		Book updatedBook = restTemplate.getForObject(getRootUrl() + "/library/v1/books/1", Book.class);
		assertEquals(updatedBook.getPublisher(), book.getPublisher());
		assertEquals(updatedBook.getAuthor(), book.getAuthor());
		assertEquals(updatedBook.getTitle(), book.getTitle());
	}

	@Test
	public void testDeleteBook() {
		Book book1 = new Book("title1", "author", "publisher", 2010);
		Book book2 = new Book("title2", "author2", "publisher", 2010);
		Book book3 = new Book("title3", "author4", "publisher2", 2011);
		restTemplate.postForEntity(getRootUrl() + "/library/v1/books", book1, Book.class);
		restTemplate.postForEntity(getRootUrl() + "/library/v1/books", book2, Book.class);
		restTemplate.postForEntity(getRootUrl() + "/library/v1/books", book3, Book.class);

		restTemplate.delete(getRootUrl() + "/library/v1/books/1");
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> entity = new HttpEntity<String>(null, headers);

		ResponseEntity<List> response = restTemplate.exchange(getRootUrl() + "/library/v1/books",
				HttpMethod.GET, entity, List.class);
		assertEquals(2, response.getBody().size());
	}

	@Test
	public void testCreateBookWithSameTitleAndAutherSecondTime() {
		Book book1 = new Book("title1", "author", "publisher", 2010);
		Book book2 = new Book("title1", "author", "publisher", 2010);
		ResponseEntity<Book> postResponse1 = restTemplate.postForEntity(getRootUrl() + "/library/v1/books", book1, Book.class);
		ResponseEntity<Book> postResponse2 = restTemplate.postForEntity(getRootUrl() + "/library/v1/books", book2, Book.class);
		assertEquals(postResponse2.getStatusCodeValue(), 404);
	}

}
