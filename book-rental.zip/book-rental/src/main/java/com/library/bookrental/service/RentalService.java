package com.library.bookrental.service;

import com.library.bookrental.entity.Rental;
import com.library.bookrental.repository.RentalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RentalService {

    private final RentalRepository rentalRepository;

    @Autowired
    public RentalService(RentalRepository rentalRepository) {
          this.rentalRepository = rentalRepository;
    }

    public List<Rental> getAllRentals(){
        return rentalRepository.findAll();
    }

    public Rental saveRental(final Rental rental){
        return rentalRepository.save(rental);
    }

    public Optional<Rental> getRentalById(final Long id){
        return rentalRepository.findById(id);
    }

    public void deleteRental(final Rental rental){
          rentalRepository.delete(rental);
    }
}
