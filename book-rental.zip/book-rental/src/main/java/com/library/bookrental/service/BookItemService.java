package com.library.bookrental.service;

import com.library.bookrental.entity.BookItem;
import com.library.bookrental.repository.BookItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BookItemService {

    private final BookItemRepository bookItemRepository;

    @Autowired
    public BookItemService(BookItemRepository bookItemRepository) {
        this.bookItemRepository = bookItemRepository;
    }

    public BookItem saveBookItem(final BookItem bookItem) {
        return bookItemRepository.save(bookItem);
    }

    public List<BookItem> getAllBookItems() {
        return bookItemRepository.findAll();
    }

    public Optional<BookItem> getBookItemById(final Long id) {
        return bookItemRepository.findById(id);
    }

    public void deleteBookItem(BookItem bookItem) {
        bookItemRepository.delete(bookItem);
    }

    public Long getNumberOfBooksByTitle(String title) {
        return bookItemRepository.countAllByBook_Title(title);
    }

    public Long getNumberOfBooksByAuthor(String author) {
        return bookItemRepository.countAllByBook_Author(author);
    }

    public Long getNumberOfBooksByPublisher(String publisher) {
        return bookItemRepository.countAllByBook_Publisher(publisher);
    }
}
