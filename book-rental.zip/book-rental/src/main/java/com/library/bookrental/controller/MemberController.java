package com.library.bookrental.controller;

import com.library.bookrental.entity.Member;
import com.library.bookrental.exception.ResourceNotFoundException;
import com.library.bookrental.service.MemberService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/library/v1")
public class MemberController {
	@Autowired
	private MemberService memberService;

	@GetMapping("/members")
	public List<Member> getAllMembers() {
		return memberService.getAllMembers();
	}

	@GetMapping("/members/{id}")
	public ResponseEntity<Member> getMemberById(@PathVariable(value = "id") Long memeberId)
			throws ResourceNotFoundException {
		Member member = memberService.getMemberById(memeberId)
				.orElseThrow(() -> new ResourceNotFoundException("Member not found for this id :: " + memeberId));
		return ResponseEntity.ok().body(member);
	}

	@PostMapping("/members")
	public Member createMember(@Valid @RequestBody Member member) {
		return memberService.saveMember(member);
	}

	@PutMapping("/members/{id}")
	public ResponseEntity<Member> updateMember(@PathVariable(value = "id") Long memberId,
                                                   @Valid @RequestBody Member memberDetails) throws ResourceNotFoundException {
		Member member = memberService.getMemberById(memberId)
				.orElseThrow(() -> new ResourceNotFoundException("Member not found for this id :: " + memberId));

		member.setLastName(memberDetails.getLastName());
		member.setFirstName(memberDetails.getFirstName());
		final Member updatedMember = memberService.saveMember(member);
		return ResponseEntity.ok(updatedMember);
	}

	@DeleteMapping("/members/{id}")
	public Map<String, Boolean> deleteMember(@PathVariable(value = "id") Long memberId)
			throws ResourceNotFoundException {
		Member Member = memberService.getMemberById(memberId)
				.orElseThrow(() -> new ResourceNotFoundException("Member not found for this id :: " + memberId));

		memberService.deleteMember(Member);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}
}
