package com.library.bookrental.controller;

import com.library.bookrental.entity.Book;
import com.library.bookrental.exception.ResourceNotFoundException;


import com.library.bookrental.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/library/v1")
public class BookController {
	@Autowired
	private BookService bookService;

	@GetMapping("/books")
	public List<Book> getAllBooks() {
		return bookService.getAllBooks();
	}

	@GetMapping("/books/{id}")
	public ResponseEntity<Book> getBookById(@PathVariable(value = "id") Long bookId)
			throws ResourceNotFoundException {
		Book book = bookService.getBookById(bookId)
				.orElseThrow(() -> new ResourceNotFoundException("Book not found for this id :: " + bookId));
		return ResponseEntity.ok().body(book);
	}

	@PostMapping("/books")
	public Book createBook(@Valid @RequestBody Book book) throws ResourceNotFoundException {
		try {
			return bookService.saveBook(book);
		}catch (DataIntegrityViolationException e){
			throw new ResourceNotFoundException("Book creation failed, check if the book with the same auther and title already exists ::"+book.getAuthor() +":"+book.getTitle());
		}
	}

	@PutMapping("/books/{id}")
	public ResponseEntity<Book> updateBook(@PathVariable(value = "id") Long bookId,
                                                   @Valid @RequestBody Book bookDetails) throws ResourceNotFoundException {
		Book book = bookService.getBookById(bookId)
				.orElseThrow(() -> new ResourceNotFoundException("Book not found for this id :: " + bookId));

		book.setTitle(bookDetails.getTitle());
		book.setAuthor(bookDetails.getAuthor());
		book.setPublisher(bookDetails.getPublisher());
		book.setPublishingYear(bookDetails.getPublishingYear());
		final Book updatedBook = bookService.saveBook(book);
		return ResponseEntity.ok(updatedBook);
	}

	@DeleteMapping("/books/{id}")
	public Map<String, Boolean> deleteBook(@PathVariable(value = "id") Long bookId)
			throws ResourceNotFoundException {
		Book book = bookService.getBookById(bookId)
				.orElseThrow(() -> new ResourceNotFoundException("Book not found for this id :: " + bookId));

		bookService.deleteBook(book);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}
}
