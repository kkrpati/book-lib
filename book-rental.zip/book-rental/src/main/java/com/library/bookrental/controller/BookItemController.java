package com.library.bookrental.controller;

import com.library.bookrental.dto.BookItemDto;
import com.library.bookrental.entity.Book;
import com.library.bookrental.entity.BookItem;
import com.library.bookrental.exception.ResourceNotFoundException;
import com.library.bookrental.service.BookItemService;
import com.library.bookrental.service.BookService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/library/v1")
public class BookItemController {
	@Autowired
	private BookItemService bookItemService;
	@Autowired
	private BookService bookService;

	@GetMapping("/book/items")
	public List<BookItem> getAllBookItems() {
		return bookItemService.getAllBookItems();
	}

	@GetMapping("/book/items/{id}")
	public ResponseEntity<BookItem> getBookItemById(@PathVariable(value = "id") Long bookItemId)
			throws ResourceNotFoundException {
		BookItem bookItem = bookItemService.getBookItemById(bookItemId)
				.orElseThrow(() -> new ResourceNotFoundException("Book Item not found for this id :: " + bookItemId));
		return ResponseEntity.ok().body(bookItem);
	}

	@PostMapping("/book/items")
	public BookItem createBookItem(@Valid @RequestBody BookItemDto bookItemDto) throws ResourceNotFoundException {
		Book book = bookService.getBookById(bookItemDto.getBookId())
				.orElseThrow(() -> new ResourceNotFoundException("Book not found for the book item. Book id :: " + bookItemDto.getBookId()));
		return bookItemService.saveBookItem(new BookItem(book, bookItemDto.getBarcode()));
	}

	@PutMapping("/book/items/{id}")
	public ResponseEntity<BookItem> updateBookItem(@PathVariable(value = "id") Long bookItemId,
                                                   @Valid @RequestBody BookItemDto bookItemDto) throws ResourceNotFoundException {
		BookItem bookItem = bookItemService.getBookItemById(bookItemId)
				.orElseThrow(() -> new ResourceNotFoundException("Book item not found for this id :: " + bookItemId));
		if(bookItem.getBook().getId()!=bookItemDto.getBookId()){
			Book newBook = bookService.getBookById(bookItemDto.getBookId())
					.orElseThrow(() -> new ResourceNotFoundException("Book not found for this id :: " + bookItemDto.getBookId()));
			bookItem.setBook(newBook);
		}
		bookItem.setAvailable(bookItemDto.isAvailable());
		bookItem.setBarcode(bookItemDto.getBarcode());
		final BookItem updatedBookItem = bookItemService.saveBookItem(bookItem);
		return ResponseEntity.ok(updatedBookItem);
	}

	@GetMapping(value = "/book/items/title/count")
	public Long getNumberOfBooksByTitle(@RequestParam String title) {
		return bookItemService.getNumberOfBooksByTitle(title);
	}
	@GetMapping(value = "/book/items/author/count")
	public Long getNumberOfBooksByAuthor(@RequestParam String author) {
		return bookItemService.getNumberOfBooksByAuthor(author);
	}
	@GetMapping(value = "/book/items/publisher/count")
	public Long getNumberOfBooksByPublisher(@RequestParam String publisher) {
		return bookItemService.getNumberOfBooksByPublisher(publisher);
	}
}
