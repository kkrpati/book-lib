package com.library.bookrental.controller;


import com.library.bookrental.dto.RentalDto;
import com.library.bookrental.entity.BookItem;
import com.library.bookrental.entity.Member;
import com.library.bookrental.entity.Rental;
import com.library.bookrental.exception.ResourceNotFoundException;
import com.library.bookrental.service.BookItemService;
import com.library.bookrental.service.MemberService;
import com.library.bookrental.service.RentalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static java.time.temporal.ChronoUnit.DAYS;

@RestController
@RequestMapping("/library/v1")
public class RentalController {

    private final RentalService rentalService;
    private final MemberService memberService;
    private final BookItemService bookItemService;

    @Autowired
    public RentalController(RentalService rentalService, MemberService memberService, BookItemService bokItemService) {
        this.rentalService = rentalService;
        this.memberService = memberService;
        this.bookItemService = bokItemService;
    }

    @PostMapping("/rentals")
    public Rental createRental(@RequestBody RentalDto rentalDto) throws ResourceNotFoundException {
        Member member = memberService.getMemberById(rentalDto.getMemberId())
                .orElseThrow(() -> new ResourceNotFoundException("Member not found for this  MemberId :: "+rentalDto.getMemberId()));
        BookItem bookItem = bookItemService.getBookItemById(rentalDto.getBookItemId())
                .orElseThrow(() -> new ResourceNotFoundException("Book not found for this  BookItemId :: "+rentalDto.getBookItemId()));
        Rental rental = new Rental(bookItem, member, rentalDto.getRentedFrom(), rentalDto.getRentalDurationInDays());
        //Give it only if its available.
        if (!bookItem.isAvailable()){
           throw new ResourceNotFoundException("Book not available this  BookItemId :: "+rentalDto.getBookItemId());
        }
        bookItem.setAvailable(false);
        return rentalService.saveRental(rental);
    }

    @GetMapping("/rentals")
    public List<Rental> getAllRentals(){
        return rentalService.getAllRentals();
    }

    @GetMapping("/rentals/{id}")
    public ResponseEntity<Rental> getRentalById(@PathVariable(value = "id") Long rentalId) throws ResourceNotFoundException {
        Rental rental  = rentalService.getRentalById(rentalId)
                .orElseThrow(() -> new ResourceNotFoundException("Rental not found for this  rentalId :: "+rentalId));
        return ResponseEntity.ok().body(rental);
    }

    @PutMapping("/rentals/{id}")
    public ResponseEntity<Rental> updateRental(@PathVariable(value = "id") Long rentalId,
    @Valid @RequestBody RentalDto rentalDto) throws ResourceNotFoundException {
        Rental rental  = rentalService.getRentalById(rentalId)
                .orElseThrow(() -> new ResourceNotFoundException("Rental not found for this  rentalId :: "+rentalId));

        LocalDate returningOn =  rentalDto.getReturnedOn();
        /* Update the below fields will be updated only if the user supplies them in the input json */
        if(null!=rentalDto.getRentedFrom()){
            rental.setRentedFrom(rentalDto.getRentedFrom());
        }
        if(null!=rentalDto.getRentalDurationInDays()){
            rental.setRentalDurationInDays(rentalDto.getRentalDurationInDays());
        }
        if(null!=rentalDto.getBookItemId() && rentalDto.getBookItemId()>0){
            BookItem bookItem = bookItemService.getBookItemById(rentalDto.getBookItemId())
                    .orElseThrow(() -> new ResourceNotFoundException("BookItem not found for this  bookItemId :: "+rentalDto.getBookItemId()));
            rental.setBookItem(bookItem);
        }
        if(null!=rentalDto.getMemberId() && rentalDto.getMemberId()>0){
            Member member = memberService.getMemberById(rentalDto.getMemberId())
                    .orElseThrow(() -> new ResourceNotFoundException("BookItem not found for this  bookItemId :: "+rentalDto.getMemberId()));
            rental.setMember(member);
        }
        // Logic for returning. If the user supplied the returnedOn which is today or before, we accept that as returned and make it available
        // We wanted to make it available only first time when it is returned.
        if((null==rental.getReturnedOn()&&returningOn!=null) && (returningOn.isBefore(LocalDate.now())|| returningOn.isEqual(LocalDate.now()))){
            rental.getBookItem().setAvailable(true);
            rental.setDamaged(rentalDto.getIsDamaged());
            rental.setReturnedOn(returningOn);
            long totalRentedDays= DAYS.between(rental.getRentedFrom(), rentalDto.getReturnedOn());
            if(totalRentedDays>rental.getRentalDurationInDays()){
                rental.setLateReturn(true);
            }
        }else { //This is to simply update the returning date
            rental.setReturnedOn(returningOn);
        }

        return ResponseEntity.ok(rentalService.saveRental(rental));
    }

    @DeleteMapping("/rentals/{id}")
    public Map<String, Boolean> deleteRental(@PathVariable(value = "id") Long rentalId) throws ResourceNotFoundException {
        Rental rental  = rentalService.getRentalById(rentalId)
                .orElseThrow(() -> new ResourceNotFoundException("Rental not found for this  rentalId :: "+rentalId));
        rentalService.deleteRental(rental);
        Map<String, Boolean> response = new HashMap<>();
        response.put("deleted", Boolean.TRUE);
        return response;
    }

}
