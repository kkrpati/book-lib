package com.library.bookrental.entity;


import lombok.*;

import javax.persistence.*;
import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity
@Table(name = "RENTALS")
public class Rental {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "ID", unique = true, nullable = false)
    private Long id;


    @Column(name = "RENTED_FROM", nullable = false)
    private LocalDate rentedFrom;

    @Column(name = "RENTAL_DURATION", nullable = false)
    private int rentalDurationInDays;

    @Column(name = "RETURNED_ON")
    private LocalDate returnedOn;

    @Column(name = "DAMAGED", columnDefinition = "boolean default false")
    private boolean isDamaged;

    @Column(name = "LATE_RETURN", columnDefinition = "boolean default false")
    private boolean isLateReturn;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "BOOK_ITEM_ID")
    private BookItem bookItem;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "MEMBER_ID")
    private Member member;

    public Rental(BookItem bookItem, Member member, LocalDate rentedFrom, int rentalDurationInDays) {
        this.bookItem = bookItem;
        this.member = member;
        this.rentedFrom =(null!=rentedFrom)?rentedFrom:LocalDate.now();
        this.isDamaged = false;
        this.isLateReturn = false;
        this.rentalDurationInDays=rentalDurationInDays;
    }
}
