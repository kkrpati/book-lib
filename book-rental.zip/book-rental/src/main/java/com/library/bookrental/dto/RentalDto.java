package com.library.bookrental.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.time.LocalDate;

@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class RentalDto {
    private Long rentalId;
    private Long bookItemId;
    private Long memberId;
    private LocalDate rentedFrom;
    private LocalDate returnedOn;
    private Integer rentalDurationInDays;
    private Boolean isDamaged;
}