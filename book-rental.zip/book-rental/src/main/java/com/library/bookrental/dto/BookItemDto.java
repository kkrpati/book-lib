package com.library.bookrental.dto;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class BookItemDto {
    private Long bookItemId;
    private Long bookId;
    private String barcode;
    private boolean available;


}