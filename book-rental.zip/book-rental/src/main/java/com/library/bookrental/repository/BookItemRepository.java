package com.library.bookrental.repository;

import com.library.bookrental.entity.BookItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Transactional
@Repository
public interface BookItemRepository extends JpaRepository<BookItem, Long>{
    Long countAllByBook_Title(String title);
    Long countAllByBook_Author(String author);
    Long countAllByBook_Publisher(String publisher);
}