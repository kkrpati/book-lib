package com.library.bookrental.entity;

import lombok.*;

import javax.persistence.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity
@Table(name = "BOOK", uniqueConstraints={@UniqueConstraint(columnNames = {"title", "author"})
})
public class Book {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "ID", unique = true)
    private Long id;

    @Column(name = "TITLE", nullable = false)
    private String title;

    @Column(name = "AUTHOR", nullable = false)
    private String author;

    @Column(name = "PUBLISHER")
    private String publisher;

    @Column(name = "PUBLISHING_YEAR")
    private int publishingYear;

/*    @JsonManagedReference
    @OneToMany(
            targetEntity = BookItem.class,
            //mappedBy = "book",
            //cascade = CascadeType.ALL,
            orphanRemoval = true,
            fetch = FetchType.LAZY
    )
    private List<BookItem> bookItems = new ArrayList<>();*/

    public Book(String title, String author, String publisher, int publishingYear) {
        this.title = title;
        this.author = author;
        this.publisher = publisher;
        this.publishingYear = publishingYear;
    }
}
