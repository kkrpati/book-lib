package com.library.bookrental.entity;


import lombok.*;
import org.springframework.stereotype.Component;

import javax.persistence.*;

@Component
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity
@Table(name = "BOOK_ITEMS")
public class BookItem {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "ID", unique = true, nullable = false)
    private Long id;

    @Column(name = "AVAILABLE", nullable = false ,columnDefinition = "boolean default true")
    private boolean available=true;

    //@JsonBackReference
    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "BOOK_ID")
    private Book book;

    @Column(name = "BARCODE")
    private String barcode;

    public BookItem(Book book, String barcode) {
        this.book = book;
        this.barcode = barcode;
    }
}
